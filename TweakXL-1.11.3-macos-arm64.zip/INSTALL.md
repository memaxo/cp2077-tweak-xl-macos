# TweakXL macOS Installation

## Requirements
- macOS 14+ (Sonoma) on Apple Silicon
- Cyberpunk 2077 for macOS
- RED4ext-macos installed and working

## Installation Steps

1. Copy `TweakXL/` folder to `<game>/red4ext/plugins/`
2. Copy `r6/` folder contents to `<game>/r6/`
3. Launch game with `launch_red4ext.sh`

## File Structure After Install
```
<game>/
├── red4ext/
│   └── plugins/
│       └── TweakXL/
│           ├── TweakXL.dylib
│           ├── ExtraFlats.dat
│           └── InheritanceMap.dat
└── r6/
    ├── scripts/      (TweakXL scripts)
    └── tweaks/       (Your YAML tweaks go here)
```

## Creating Tweaks

Place `.yaml` files in `<game>/r6/tweaks/`:

```yaml
# Example: Modify weapon damage
Items.Preset_Katana_Default:
  damage: 100
```

See wiki for full documentation:
https://github.com/psiberx/cp2077-tweak-xl/wiki
